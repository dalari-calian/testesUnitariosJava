package br.com.cpassos.servicos;

import static br.com.cpassos.utils.DataUtils.adicionarDias;

import java.util.Date;

import br.com.cpassos.entidades.Filme;
import br.com.cpassos.entidades.Locacao;
import br.com.cpassos.entidades.Usuario;

public class LocacaoService {
	
	public Locacao alugarFilme(Usuario usuario, Filme filme) {
		Locacao locacao = new Locacao();
		locacao.setFilme(filme);
		locacao.setUsuario(usuario);
		locacao.setDataLocacao(new Date());
		locacao.setValor(filme.getPrecoLocacao());

		//Entrega no dia seguinte
		Date dataEntrega = new Date();
		dataEntrega = adicionarDias(dataEntrega, 1);
		locacao.setDataRetorno(dataEntrega);
		
		//Salvando a locacao...	
		//TODO adicionar método para salvar
		
		return locacao;
	}

	public static void main(String[] args) {
		//preparacao
		
		//instancia dos objetos
		//--Uma forma de fazer
		Filme filme = new Filme("Rambo", 3, 15.9);//inserindo os dados na classe filme  !OBS: Insira na ordem que a vari�vel est� declarada na classe
		//filme.setNome(Rambo);
		//filme.setEstoque(3);
		//filme.setPrecoLocacao(15.9);
		      
		//--Outra forma de fazer     
		Usuario usuario = new Usuario();
		usuario.setNome("Calian");
		
		LocacaoService locacaoS = new LocacaoService(); //Criando o objeto 'locacaoS' para chamar o m�todo 'alugarFilmes'
				
		//acao
		Locacao retornoFilme = locacaoS.alugarFilme(usuario, filme);//'chamando' o m�todo
				
		//verificacao
		System.out.printf("Nome do filme: ") ; System.out.println(filme.getNome());//Mostra no console o que esta retornando o resultado desejado
		System.out.printf("Valor da loca��o: R$") ; System.out.println(filme.getPrecoLocacao());
		System.out.printf("Pessoa que alugou: "); System.out.println(usuario.getNome());
		
		
		//--Outra forma de fazer
		System.out.println(retornoFilme.getValor());
				
		
	}
}